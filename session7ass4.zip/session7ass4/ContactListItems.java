package com.example.ass4_session7.session7ass4;

/**
 * Created by trident on 30/5/16.
 */
public class ContactListItems {
    String slno;
    String name;
    String phone;

    public String getSlno() {
        return slno;
    }

    public void setSlno(String slno) {
        this.slno = slno;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
