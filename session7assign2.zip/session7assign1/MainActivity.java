package com.example.trident.autocompleteapp;
import java.util.List;


import android.os.Bundle;
import android.app.Activity;
import android.widget.ArrayAdapter;

import com.example.trident.autocompleteapp.CustomAutoCompleteTextChangedListener;
import com.example.trident.autocompleteapp.CustomAutoCompleteView;
import com.example.trident.autocompleteapp.DatabaseHandler;
import com.example.trident.autocompleteapp.MyObject;
import com.example.trident.autocompleteapp.R;

public class MainActivity extends Activity {

    /*
     * Change to type CustomAutoCompleteView instead of AutoCompleteTextView
     * since we are extending to customize the view and disable filter
   import java.util.List;

import android.os.Bundle;
import android.app.Activity;
import android.widget.ArrayAdapter;

public class MainActivity extends Activity {

    /*
     * Change to type CustomAutoCompleteView instead of AutoCompleteTextView
     * since we are extending to customize the view and disable filter
     * The same with the XML view, type will be CustomAutoCompleteView
     */
    CustomAutoCompleteView myAutoComplete;

    // adapter for auto-complete
    ArrayAdapter<String> myAdapter;

    // for database operations
    DatabaseHandler databaseH;

    // just to add some initial value
    String[] item = new String[] {"Please search..."};

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



            // instantiate database handler
            databaseH = new DatabaseHandler(MainActivity.this);

            // put sample data to database
            insertSampleData();

            // autocompletetextview is in activity_main.xml
            myAutoComplete = (CustomAutoCompleteView) findViewById(R.id.myautocomplete);

            // add the listener so it will tries to suggest while the user types
            myAutoComplete.addTextChangedListener(new CustomAutoCompleteTextChangedListener(this));

            // set our adapter
            myAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, item);
            myAutoComplete.setAdapter(myAdapter);


    }

    public void insertSampleData(){

        // CREATE
        databaseH.create( new MyObject("Argentina") );//
        databaseH.create( new MyObject("India") );
        databaseH.create( new MyObject("France") );
        databaseH.create( new MyObject("Italy") );
        databaseH.create( new MyObject("Switzerland") );
        databaseH.create( new MyObject("June") );
        databaseH.create( new MyObject(" United Kingdom") );
        databaseH.create( new MyObject("United States") );
        databaseH.create( new MyObject("Sri Lanka") );
        databaseH.create( new MyObject("Madagascar") );
        databaseH.create( new MyObject("Spain") );
        databaseH.create( new MyObject("Germany") );
        databaseH.create( new MyObject("New Caledonia") );
        databaseH.create( new MyObject("New Zealand") );
        databaseH.create( new MyObject("China") );
        databaseH.create( new MyObject("France") );
        databaseH.create( new MyObject("Canada") );
        databaseH.create( new MyObject("Cambodia") );
        databaseH.create( new MyObject("Bahrain") );
        databaseH.create( new MyObject("Australia") );
        databaseH.create( new MyObject("Venezuela") );

    }

    // this function is used in CustomAutoCompleteTextChangedListener.java
    public String[] getItemsFromDb(String searchTerm){

        // add items on the array dynamically
        List<MyObject> products = databaseH.read(searchTerm);
        int rowCount = products.size();

        String[] item = new String[rowCount];
        int x = 0;

        for (MyObject record : products) {

            item[x] = record.objectName;
            x++;
        }

        return item;
    }

}
/* Indonesia
18 Iran
19 Ireland
20 Israel
21 Italy
22 Japan
23 Jordan
24 Kenya
25 Kuwait
26 Lebanon
27 Macau
28
29 Morocco
30 Nepal
31 Netherlands
32 New Zealand
33 Nicaragua
34 Pakistan
35 Papua New Guinea
36 Philippines
37 Poland
38 Russia
39 South Korea
40
41
42
43 Taiwan
44 Tunisia
45 Turkey
46 United Arab Emirates
47 United Kingdom
48
49 Venezuela
50*/

