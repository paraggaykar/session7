package com.example.trident.autocompleteapp;

public class MyObject {

    public String objectName;

    // constructor for adding sample data
    public MyObject(String objectName){

        this.objectName = objectName;
    }

}